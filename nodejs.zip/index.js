/**
 * Created by john on 2017/6/29.
 */
window.onload=function () {
    alert("一切正常");
};